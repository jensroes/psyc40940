library(shiny)
library(tidyverse)

d_participants <- read_csv("data/participant_reaction_times.csv",
                           show_col_types = FALSE)

ui <- fluidPage(
  titlePanel("Participant reaction times"),
  p("Each value is one participant's mean reaction time across familiarisation conditions, in milliseconds."),
  sidebarLayout(
    sidebarPanel(
      checkboxGroupInput("groups", "Output groups",
                         choices = c("Spoken output" = "speech",
                                     "Written output" = "writing"),
                         selected = c("speech", "writing")),
      sliderInput("vocab_range", "Keep vocabulary scores within",
                  min = 0.80, max = 1.00,
                  value = c(0.80, 1.00), step = 0.01),
      sliderInput("binwidth", "Histogram bin width (ms)",
                  min = 25, max = 300, value = 100, step = 25),
      helpText("Groups and vocabulary-score range change which participants are included in all three views. Pooled or Separate groups changes only how the density view displays them. Bin width changes only the histogram.")
    ),
    mainPanel(
      textOutput("selection_note"),
      tabsetPanel(
        tabPanel("Distribution",
          p("The histogram pools the selected groups. Compare groups separately in the other views."),
          plotOutput("rt_plot")
        ),
        tabPanel("Individual values",
          p("Compare the median, spread and individual participant means for each selected group."),
          plotOutput("values_plot")
        ),
        tabPanel("Density comparison",
          p("---"),
          ---("density_view", "Compare groups using",
              choices = c("All selected participants" = "pooled",
                          "Separate groups" = "groups"),
              selected = "groups"),
          plotOutput("---")
        )
      ),
      helpText("The groups contain different participants; these plots do not establish a causal effect of output group.")
    )
  )
)

server <- function(input, output) {
  selected_data <- reactive({
    req(input$vocab_range)
    selected <- filter(
      d_participants,
      modality %in% input$groups,
      vocabulary_score >= input$vocab_range[1],
      vocabulary_score <= input$vocab_range[2]
    )
    validate(need(
      nrow(selected) > 0,
      "No participants match. Select a group or widen the vocabulary-score range."
    ))
    selected
  })
  
  output$selection_note <- renderText({
    paste("Participants shown:", nrow(selected_data()))
  })
  
  output$rt_plot <- renderPlot({
    ggplot(selected_data(), aes(x = mean_rt)) +
      geom_histogram(binwidth = input$binwidth) +
      # facet_wrap(~modality) +
      labs(x = "Participant mean reaction time (ms)",
           y = "Participants")
  })
  
  output$values_plot <- renderPlot({
    ggplot(selected_data(), aes(x = modality, y = mean_rt)) +
      geom_boxplot(width = 0.25, outlier.shape = NA) +
      geom_point(position = position_jitter(width = 0.08,
                                           height = 0, seed = 7),
                 alpha = 0.6) +
      labs(x = "Output group", y = "Participant mean reaction time (ms)")
  })
  output$density_plot <- ---({
    req(input$density_view)
    validate(need(
      nrow(selected_data()) >= 2,
      "A density curve needs at least two participants. Widen the vocabulary-score range."
    ))

    p_density <- ggplot(---, aes(x = mean_rt)) +
      labs(x = "Participant mean reaction time (ms)",
           y = "Density")

    if (input$density_view == "groups") {
      validate(need(
        all(table(selected_data()$modality) >= 2),
        "Group density curves need at least two participants per selected group. Widen the range or choose All selected participants."
      ))
      p_density <- p_density +
        ---(aes(colour = modality, fill = ---), alpha = 0.25) +
        labs(colour = "Output group", fill = "Output group")
    } else {
      p_density <- p_density + geom_density()
    }
    p_density
  })
}

shinyApp(ui, server)
