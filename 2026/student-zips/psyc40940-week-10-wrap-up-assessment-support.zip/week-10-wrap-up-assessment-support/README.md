# Week 10: Connect your app controls and prepare your portfolio

Class progress recorded on 19 November 2026: Week 9 reached one static ggplot displayed inside Shiny, without connected input controls. Week 10 resumes from that point. Protect about 75 minutes for project organisation, implementation and testing; do not assume students arrive with a completed dashboard or report.

Start by copying the supplied psyc40940-portfolio folder and double-clicking psyc40940-portfolio.Rproj. Students copy their working Week 9 script as root-level app.R, put actual data in data/, and copy any report/bibliography already started. Keep the weekly original as a backup. app.R, report.Rmd and .Rproj share the same folder, so Console checks, knitting and Run App use data/... rather than switching to ../data/... . If needed, `supplied_data_app.R` is a runnable fallback with one working mean-count plot, no input controls and an empty second view. `data/participant_rates.csv` is the unchanged Week 9 teaching extract. `session-guide.html` provides explicit code-completion and modification tasks; students edit and run complete R scripts, with no typing along with live coding.

Core sequence: Exercise 1 organises the project and working plot; Exercise 2 includes both connecting and testing controls, and Exercise 3 adds the second view. Identify the working plot and intended input; add UI controls, shared reactive filtering and the first plot's data connection; test valid selections and recovery; add a second view using the same selection, explanations and brief feedback from another student. The guide uses `---` for student completions. The small `worked_example_app.R` is introduced only at the end, after an attempt.

First 50 minutes: organise the assessment project, copy app/data and test the existing plot 10; guided tracing and one-control example 5; implement controls/shared filtering and connect the first plot 25; test selections, recovery and brief class feedback 10.

Second 50 minutes: add the complementary view, explanations and test/refine with feedback 25; submission walkthrough 15; static-report/formative-feedback reminder 5; next steps and close 5. A working first input-to-plot connection is the minimum useful class checkpoint; two plots and two useful controls remain the workshop target. Save a runnable version and the next step if unfinished.

The submission walkthrough covers a dedicated RStudio project, one Rmd and rendered output, separate app, actual data and dependencies, relative paths, package/version information, anonymity, the official NOW AI declaration and the complete extracted-ZIP test. The assessment brief is authoritative. The full report-preparation and 15-minute ZIP exercises are independent practice/reference, not extra compulsory in-class tasks. Detailed instructions remain in the guide and the NOW Summative submission guide.

The static report still requires four different visualisation types with interpretation, design commentary and reflection. Use formative feedback to identify a priority. No full new report or polished assessment ZIP is expected during the 100-minute app workshop.

`submission-example/` remains a separate reproducibility practice project, with report Rmd/HTML, four static examples, bibliography, data and a richer app. It is not the starting app for continuation and must not be submitted wholesale. Its report.Rmd, app.R and portfolio.Rproj are together at the project root; both report and app read data/ with identical relative paths. The full practice project and portfolio resources are available for independent use.

Guide sources and gfx/ stay with teaching sources; students receive the self-contained HTML guide, app scripts and data. Rebuild the student ZIP with `2026/scripts/package_workshop_materials.py`. Defer Week 10 PPTX rendering and publication until requested.

## Catch-up routes

All students begin with the assessment-project task. Those with no working app but with a dataset use own_data_app.R, an unchanged copy of the Week 9 template, load their data and get one plot working in its first render block. Those with neither an app nor data use supplied_data_template.R, the Week 9 supplied-data template, with the prepared CSV and the guide's first-plot completion. Both then join the controls task. supplied_data_app.R remains a one-plot reference/fallback; the full worked_example_app.R is for comparison after an attempt. The guide keeps catch-up instructions collapsed, so continuing students can proceed directly to their next connection.

Exercise 1 is explicitly framed as resolving Week 9's path/data-loading problems: Console checks and Run App sometimes started from different folders. Organising the app, report and project together gives the import code one consistent starting point before students add controls.

AI coding support is optional within the existing workshop time. A short slide and collapsed prompt show students how to use distinct(data, variable) to obtain the variable name and observed values. They copy the command/output and current app code, then ask how and where to add one control in the UI/server. The prompt requests a brief explanation; students read and test the changes. This follows the brief's AMBER allowance for code support; submitted commentary, interpretation, design rationale and reflection remain the student's own work and use must be declared.

## Lightweight assessment starter

`psyc40940-portfolio/` supplies psyc40940-portfolio.Rproj, a blank but renderable report.Rmd, a one-entry references.bib, apa.csl and data/README.md. It is included in the Week 10 ZIP and distributed separately as psyc40940-portfolio.zip. All students copy this folder, copy last week's app as app.R, put their data file in data/ and double-click psyc40940-portfolio.Rproj. Data may use any supported format; retain the appropriate import function. They supply their own app.R and data. Four empty named figure chunks have caption placeholders; default echo is FALSE. Report instructions are HTML comments, with details in the README and guide. The example citation must be replaced. This setup fits Exercise 1; report completion remains independent.

## Choosing a download

Students with their Week 9 app and data need only psyc40940-portfolio.zip and the online guide. Students needing catch-up templates or practice data use the larger Week 10 ZIP, which already contains the identical portfolio folder and HTML guide. Both ZIPs are not required. The larger download also supplies optional reproducibility examples. Slides, guide and NOW text explain these routes before Exercise 1.
